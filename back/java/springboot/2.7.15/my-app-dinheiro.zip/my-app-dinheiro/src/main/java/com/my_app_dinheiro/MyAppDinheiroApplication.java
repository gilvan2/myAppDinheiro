package com.my_app_dinheiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAppDinheiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyAppDinheiroApplication.class, args);
	}

}

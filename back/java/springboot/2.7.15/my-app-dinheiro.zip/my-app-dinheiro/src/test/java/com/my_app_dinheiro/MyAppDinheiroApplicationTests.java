package com.my_app_dinheiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAppDinheiroApplicationTests {

	@Test
	void contextLoads() {
	}

}
